</div>
  <div class="foot">© <?php echo date('Y'); ?> <?php echo htmlspecialchars(APP_TITLE); ?> — Personal Cloud</div>
</div>
</body>
</html>